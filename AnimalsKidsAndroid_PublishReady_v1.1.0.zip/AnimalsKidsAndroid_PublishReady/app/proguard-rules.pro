# No custom ProGuard rules for the first demo.
