# AnimalsKidsAndroid v1.1.0

نسخة مطورة من لعبة «عالم الحيوانات للأطفال».

الجديد:
- 10 أسئلة عشوائية.
- 8 حيوانات.
- نقاط ونجوم و3 محاولات.
- نطق عربي عبر Android TextToSpeech.
- شاشة نتيجة وإعادة اللعب.
- بدون حسابات وإعلانات وصلاحيات حساسة.
- ملفات تجهيز المتجر وسياسة الخصوصية داخل PLAY_STORE.

البناء:
افتح المجلد في Android Studio مع Android SDK 36، ثم:
Build > Generate App Bundles or APKs > Generate App Bundle.
للنشر على Google Play استخدم AAB موقّع Release.
